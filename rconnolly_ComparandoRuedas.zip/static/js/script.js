function ToggleMenu() {
    let menu = document.getElementById("menu");
    menu.style.display = menu.style.display == "block" ? "none" : "block";
}
